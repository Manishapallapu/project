package com.cts.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.models.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {
	Student findByEmail(String email);
}
