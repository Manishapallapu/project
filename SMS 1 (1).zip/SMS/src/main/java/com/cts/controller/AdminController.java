package com.cts.controller;

import java.util.Date;
import java.util.Random;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.cts.models.Admin;
import com.cts.models.Student;
import com.cts.repo.AdminRepository;
import com.cts.repo.StudentRepository;
import org.springframework.web.bind.annotation.RequestParam;



@Controller
public class AdminController {
	
	@Autowired
	private AdminRepository adminrepo;
	
	@Autowired
	private StudentRepository studentRepo;
	
	@GetMapping("/admin")
	public String adminLogin(Model model) {
		model.addAttribute("admin", new Admin());
		return "admin_functions/admin_login";
	}
	
	@GetMapping("/new/admin")
	public String adminregisterForm(Model model) {
		Admin admin = new Admin();
		model.addAttribute("admin", admin);
		return "admin_functions/admin_register";
	}

	@PostMapping("/register/admin")
	public String adminregister(Admin admin) {
		Random r = new Random();
		int num = r.nextInt(9000) + 1000;
		admin.setAdmin_id(num);
		adminrepo.save(admin);
		return "redirect:/admin";
	}
	
	@GetMapping("/adminhome")
	public String customerDisplay(Model model) {
		model.addAttribute("student", studentRepo.findAll());
		return "admin_functions/admin_dashboard";
	}

	@PostMapping("/adminhome")
	public String customersDisplay(Model model) {
		// TODO: process POST request
		model.addAttribute("student", studentRepo.findAll());
		return "admin_functions/admin_dashboard";
	}
	
	@PostMapping("/admin/login")
	public String loginSubmit(@ModelAttribute Admin admin, BindingResult bindingResult, Model model) {
	    boolean success = login(admin);
	    String res = "";
	    if (bindingResult.hasErrors()) {
	        System.out.println(bindingResult);
	        String msg = "Invalid Credintials";
	        model.addAttribute("message",msg);
	        res = "admin_functions/admin_login";
	        
	    } else if (success) {
	        res = "redirect:/adminhome";
	        model.addAttribute("Email",admin.getEmail());
	    } else {
	        res = "redirect:/admin";
	    }
	    return res;
	}
	
	public boolean login(Admin admin) {
		Admin existingUser = adminrepo.findByEmail(admin.getEmail());
		if(existingUser != null && existingUser.getPassword().equals(admin.getPassword())) {
			return true;
		}else {
			return false;
		}
	}
	
	
	//getting students done
	@GetMapping("/new/student")
	public String registerForm(Model model) {
		Student std = new Student();
		model.addAttribute("student", std);
		return "admin_functions/student_register";
	}
	
	@PostMapping("/student/register")
	public String register(Student std, Model model) {
		//TODO: process POST request
		Random r = new Random();
		int num = r.nextInt(9000)+1000;
		std.setStudent_id(num);
		Date doj = new Date();
		std.setDoj(doj);
		studentRepo.save(std);
		model.addAttribute("studentId",num);
		return "admin_functions/student_success";
	}	
	
	@GetMapping("/student/{student_id}")
	public String studUpdateForm(@PathVariable("student_id") int student_id, Model model) {
		System.out.println("1.");
		Student std = studentRepo.findById(student_id).get();
		model.addAttribute("student",std);
		return "admin_functions/student_update";
	}
	
	@PostMapping("student/update")
	public String updateStudent(Student std) {
		//TODO: process POST request
		studentRepo.save(std);
		return "redirect:/adminhome";
	}
	
	@GetMapping("/student/delete/{student_id}")
	public String deleteStudent(@PathVariable("student_id")int student_id, Model model) {
		studentRepo.deleteById(student_id);
		Student std = new Student();
		model.addAttribute("student",std);
		return "admin_functions/delete_success";
	}
	
	@PostMapping("/delete/success")
	public String deleteSuccess(Student std , Model model) {
		//TODO: process POST request
		int num = std.getStudent_id();
		model.addAttribute("ProductId", num);
		return "admin_functions/delete_success";
	}
	
	@GetMapping("/student/view/{student_id}")
	public String ViewStudent(@PathVariable("student_id") int student_id, Model model) {
		Student std = studentRepo.findById(student_id).get();
		model.addAttribute("student",std);
		return "admin_functions/view_student";
	}
	
	
}
